package com.ejb.services;

import com.jpa.entities.Customer;

public interface CustomerService {

	public void addCustomer(Customer cust);
	
}
