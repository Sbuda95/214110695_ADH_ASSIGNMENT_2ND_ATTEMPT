
package com.ejb.services.impl;
 
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.ejb.services.CustomerService;
import com.jpa.entities.Customer;

@Stateless
public class CustomerServiceImpl implements CustomerService{
	
	@PersistenceContext(name = "CustomerApp")
	private EntityManager cus;
	
	@Override
	public void addCustomer(Customer cust) {
		
		cus.persist(cust);
	}

}
