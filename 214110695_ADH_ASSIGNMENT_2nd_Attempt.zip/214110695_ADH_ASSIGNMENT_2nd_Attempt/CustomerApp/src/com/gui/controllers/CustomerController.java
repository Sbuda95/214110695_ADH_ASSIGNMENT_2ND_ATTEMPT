package com.gui.controllers;

import javax.ejb.EJB; 
import javax.faces.bean.ManagedBean;

import com.ejb.services.CustomerService;
import com.jpa.entities.Customer;


@ManagedBean
public class CustomerController {

	private Customer customer = new Customer();
	
	@EJB
	private CustomerService service;
	
	public Customer getCustomer() {
		
		return customer;
	}
	
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	public void saveCustomer(Customer cust) {
		service.addCustomer(cust);
	}
	
}
